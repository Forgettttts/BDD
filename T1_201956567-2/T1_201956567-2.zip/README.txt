ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ    ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ  ヽ(✿ﾟ▽ﾟ)ノ

Trabajo: Tarea 1
Ramo: Bases de Datos (INF-239)
Profesor:Marcelo Mendoza
Fecha entrega: Domingo 13 de Junio del 2021
Nombre: Alan Eduardo Zapata Silva
Rol: 201956567-2
correo:alan.zapata@usm.cl / alan.zapata@sansano.usm.cl

\^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/   \^o^/

1)Para crear comuna, se debe entregar el nombre de la region, y el codigo de la region, si es que alguno de los dos ya existe, se printeara un error, inicialmente la comuna tendra 
0 personas. La entrada diferencia entre mayusculas y minusculas, por lo que puede existir una comuna Torres del Paine y otra llamada Torres del paine.

2)Crear region ya no es sensible a las mayusculas, por lo que no puede haber una region llamada aysen y otra Aysen.

3)Para obtener casos por comuna y casos por region, se debe pedir con el codigo correspondiente.

4)Se necesita importar previamente libreria prettytable, usada para mostrar casos totales

5)Al momento de combinar regiones y comunas, se juntaran ambas en alguna de las dos, el usuario elige cual.

Programado y testeado en Windows 10 con python (v. 3.9.0) junto con Oracle SQL developer.

（＾∀＾●）ﾉｼ   （＾∀＾●）ﾉｼ   （＾∀＾●）ﾉｼ   （＾∀＾●）ﾉｼ   （＾∀＾●）ﾉｼ   （＾∀＾●）ﾉｼ   （＾∀＾●）ﾉｼ   （＾∀＾●）ﾉｼ   （＾∀＾●）ﾉｼ   （＾∀＾●）ﾉｼ   （＾∀＾●）ﾉｼ   （＾∀＾●）ﾉｼ   （＾∀＾●）ﾉｼ   （＾∀＾●）ﾉｼ   （＾∀＾●）ﾉｼ   （＾∀＾●）ﾉｼ   （＾∀＾●）ﾉｼ   （＾∀＾●）ﾉｼ   （＾∀＾●）ﾉｼ   （＾∀＾●）ﾉｼ   （＾∀＾●）ﾉｼ   