Nombre: Alan Zapata Silva
Rol: 201956567-2
correo: alan.zapata@usm.cl

Detalles desarrollo: Desarrollado en Ubuntu 20.04 con XAMPP 8.0.8-1, probado en Firefox.

Lista de cambios respecto a la planificación inicial:

1. Se añadió correo dentro de los atributo de usmer.

2. Cambios en tabla Tags:
    a)Se añadio como <<fk>> a "Creador" (Para facilitar ver tags de cada usuario).
    b)Se elimino "apariciones"(Ya que los tops se haran con una vista).

Instrucciones:
    1)En Ubuntu 20.04 tener instalado XAMPP 8.0.8-1.
    2)Ejecutar en consola "sudo nautilus"
    3)Ir al directorio opt/lampp/htdocs y ahi pegar la carpeta "Tarea2".
    4)Ir a un navegador(de preferencia Firefox) e ingresar en la barra de busqueda "localhost/Tarea2"

~Nota para ayudante: No sea malo pofavo, fueron semanas complicadas y deje mis horas de sueño, para poder cumplir con lo mas que pude de esta tarea, podra ver que manejo el codigo en la defensa :c ~