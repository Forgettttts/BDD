<?php
include_once'header.php';
require_once 'includes/funciones.inc.php';
?>

<div class="wrapper">
    <p> Perfil de <?php echo $_SESSION["usuario"]; ?></p>
    <br>
    <p> Perfil de <?php echo $_SESSION["nombre"]; ?></p>
    <br>
    <p>Correo <?php echo $_SESSION["correo"]; ?></p>
    <br>
    <p>Sigues a: <?php echo $_SESSION["nombre"]; ?> personas</p>
    <br>
    <p> Te siguen <?php echo $_SESSION["nombre"]; ?> personas</p>
</div>

<?php
include_once'footer.php'
?>